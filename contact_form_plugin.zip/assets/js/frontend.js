/**
 * Contact Form Plugin - Plugin Frontend Interaction
 */
(function() {
    'use strict';
    document.addEventListener('DOMContentLoaded', function() {
        var forms = document.querySelectorAll('.contact_form_plugin-ajax-form');
        forms.forEach(function(form) {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                var btn = form.querySelector('button[type="submit"]');
                var orig = btn ? btn.innerText : '';
                if (btn) {
                    btn.disabled = true;
                    btn.innerText = 'در حال ثبت...';
                }

                var formData = new FormData(form);
                if (window.contact_form_pluginData) {
                    formData.append('action', window.contact_form_pluginData.action);
                    formData.append('nonce', window.contact_form_pluginData.nonce);
                }

                fetch(window.contact_form_pluginData ? window.contact_form_pluginData.ajax_url : '/wp-admin/admin-ajax.php', {
                    method: 'POST',
                    body: formData
                })
                .then(function(res) { return res.json(); })
                .then(function(resp) {
                    if (resp && resp.success) {
                        alert(resp.data && resp.data.message ? resp.data.message : 'عملیات موفقیت‌آمیز بود.');
                        form.reset();
                    } else {
                        alert((resp && resp.data && resp.data.message) ? resp.data.message : 'خطایی رخ داد.');
                    }
                })
                .catch(function(err) {
                    console.error('AJAX Error:', err);
                })
                .finally(function() {
                    if (btn) {
                        btn.disabled = false;
                        btn.innerText = orig;
                    }
                });
            });
        });
    });
})();
