<?php
/**
 * CLI Test Portfolio Block Theme functions and definitions
 *
 * @package CLI Test Portfolio
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'CLI_TEST_PORTFOLIO_VERSION' ) ) {
    define( 'CLI_TEST_PORTFOLIO_VERSION', '1.0.0' );
}

if ( ! function_exists( 'cli_test_portfolio_fse_setup' ) ) {
    /**
     * Sets up block theme features and supports.
     */
    function cli_test_portfolio_fse_setup() {
        // Full Site Editing Block Theme Supports
        add_theme_support( 'wp-block-styles' );
        add_theme_support( 'editor-styles' );
        add_editor_style( 'style.css' );
    }
}
add_action( 'after_setup_theme', 'cli_test_portfolio_fse_setup' );

if ( ! function_exists( 'cli_test_portfolio_fse_scripts' ) ) {
    /**
     * Enqueue block theme standalone assets with zero external CDN dependency.
     */
    function cli_test_portfolio_fse_scripts() {
        wp_enqueue_style(
            'cli_test_portfolio-block-theme',
            get_stylesheet_uri(),
            array(),
            CLI_TEST_PORTFOLIO_VERSION
        );

        wp_enqueue_script(
            'cli_test_portfolio-interactions',
            get_template_directory_uri() . '/assets/js/theme-interactions.js',
            array(),
            CLI_TEST_PORTFOLIO_VERSION,
            true
        );

        wp_localize_script(
            'cli_test_portfolio-interactions',
            'cli_test_portfolioSettings',
            array(
                'ajax_url'   => admin_url( 'admin-ajax.php' ),
                'nonce'      => wp_create_nonce( 'cli_test_portfolio_fse_nonce' ),
                'is_rtl'     => is_rtl(),
                'theme_slug' => 'cli_test_portfolio'
            )
        );
    }
}
add_action( 'wp_enqueue_scripts', 'cli_test_portfolio_fse_scripts' );
