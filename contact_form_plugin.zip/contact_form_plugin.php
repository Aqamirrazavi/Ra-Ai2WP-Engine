<?php
/**
 * Plugin Name:       Contact Form Plugin
 * Plugin URI:        https://wordpress.org/plugins/contact_form_plugin/
 * Description:       Modular WordPress Plugin automatically converted from React with 100% isolation and security.
 * Version:           1.0.0
 * Author:            RTW Universal Compiler
 * Author URI:        https://github.com/rtw-converter
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       contact_form_plugin
 * Domain Path:       /languages
 * Requires at least: 6.2
 * Requires PHP:      8.0
 *
 * @package Contact Form Plugin
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

if ( ! defined( 'CONTACT_FORM_PLUGIN_VERSION' ) ) {
    define( 'CONTACT_FORM_PLUGIN_VERSION', '1.0.0' );
}

if ( ! defined( 'CONTACT_FORM_PLUGIN_FILE' ) ) {
    define( 'CONTACT_FORM_PLUGIN_FILE', __FILE__ );
}

if ( ! defined( 'CONTACT_FORM_PLUGIN_DIR' ) ) {
    define( 'CONTACT_FORM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'CONTACT_FORM_PLUGIN_URL' ) ) {
    define( 'CONTACT_FORM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

if ( ! class_exists( 'Contact_Form_Plugin_Plugin_Core' ) ) {
    /**
     * Main Plugin Controller Class
     */
    final class Contact_Form_Plugin_Plugin_Core {

        /**
         * Singleton instance
         *
         * @var Contact_Form_Plugin_Plugin_Core|null
         */
        private static $instance = null;

        /**
         * Get singleton instance
         *
         * @return Contact_Form_Plugin_Plugin_Core
         */
        public static function get_instance() {
            if ( null === self::$instance ) {
                self::$instance = new self();
            }
            return self::$instance;
        }

        /**
         * Constructor: Registers core hooks
         */
        private function __construct() {
            add_action( 'init', array( $this, 'load_textdomain' ) );
            add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_frontend_assets' ) );
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
            add_action( 'admin_menu', array( $this, 'register_admin_menu' ) );
            add_action( 'admin_init', array( $this, 'register_settings' ) );

            // Shortcode
            add_shortcode( 'contact_form_plugin', array( $this, 'render_shortcode' ) );

            // AJAX Handlers
            add_action( 'wp_ajax_contact_form_plugin_submit_app', array( $this, 'handle_ajax_submission' ) );
            add_action( 'wp_ajax_nopriv_contact_form_plugin_submit_app', array( $this, 'handle_ajax_submission' ) );
        }

        /**
         * Activation handler
         */
        public static function activate() {
            if ( ! current_user_can( 'activate_plugins' ) ) {
                return;
            }
            $default_options = array(
                'enabled'      => 1,
                'title'        => 'Contact Form Plugin',
                'enable_rtl'   => 1,
                'custom_badge' => esc_html__( 'تایید شده', 'contact_form_plugin' )
            );
            add_option( 'contact_form_plugin_options', $default_options );
        }

        /**
         * Deactivation handler
         */
        public static function deactivate() {
            if ( ! current_user_can( 'activate_plugins' ) ) {
                return;
            }
            // Cleanup transient or temporary caches
        }

        /**
         * Load plugin localization
         */
        public function load_textdomain() {
            load_plugin_textdomain( 'contact_form_plugin', false, dirname( plugin_basename( CONTACT_FORM_PLUGIN_FILE ) ) . '/languages' );
        }

        /**
         * Enqueue standalone frontend styles and scripts (Zero CDN)
         */
        public function enqueue_frontend_assets() {
            wp_enqueue_style(
                'contact_form_plugin-frontend',
                CONTACT_FORM_PLUGIN_URL . 'assets/css/frontend.css',
                array(),
                CONTACT_FORM_PLUGIN_VERSION
            );

            wp_enqueue_script(
                'contact_form_plugin-frontend',
                CONTACT_FORM_PLUGIN_URL . 'assets/js/frontend.js',
                array(),
                CONTACT_FORM_PLUGIN_VERSION,
                true
            );

            wp_localize_script(
                'contact_form_plugin-frontend',
                'contact_form_pluginData',
                array(
                    'ajax_url' => admin_url( 'admin-ajax.php' ),
                    'action'   => 'contact_form_plugin_submit_app',
                    'nonce'    => wp_create_nonce( 'contact_form_plugin_plugin_action_nonce' ),
                    'is_rtl'   => is_rtl()
                )
            );
        }

        /**
         * Enqueue admin assets
         *
         * @param string $hook Admin page hook suffix.
         */
        public function enqueue_admin_assets( $hook ) {
            if ( false === strpos( $hook, 'contact_form_plugin' ) ) {
                return;
            }
            wp_enqueue_style(
                'contact_form_plugin-admin',
                CONTACT_FORM_PLUGIN_URL . 'assets/css/admin.css',
                array(),
                CONTACT_FORM_PLUGIN_VERSION
            );
        }

        /**
         * Register Settings API page in WP Admin
         */
        public function register_admin_menu() {
            add_options_page(
                esc_html__( 'تنظیمات Contact Form Plugin', 'contact_form_plugin' ),
                esc_html__( 'Contact Form Plugin', 'contact_form_plugin' ),
                'manage_options',
                'contact_form_plugin-settings',
                array( $this, 'render_admin_settings_page' )
            );
        }

        /**
         * Register plugin settings
         */
        public function register_settings() {
            register_setting( 'contact_form_plugin_options_group', 'contact_form_plugin_options', array(
                'type'              => 'array',
                'sanitize_callback' => array( $this, 'sanitize_options' )
            ) );

            add_settings_section(
                'contact_form_plugin_main_section',
                esc_html__( 'پیکربندی کلی افزونه', 'contact_form_plugin' ),
                null,
                'contact_form_plugin-settings'
            );

            add_settings_field(
                'contact_form_plugin_title_field',
                esc_html__( 'عنوان نمایشی', 'contact_form_plugin' ),
                array( $this, 'render_title_field' ),
                'contact_form_plugin-settings',
                'contact_form_plugin_main_section'
            );
        }

        /**
         * Sanitize settings options
         */
        public function sanitize_options( $input ) {
            $sanitized = array();
            if ( isset( $input['title'] ) ) {
                $sanitized['title'] = sanitize_text_field( $input['title'] );
            }
            if ( isset( $input['enabled'] ) ) {
                $sanitized['enabled'] = 1;
            } else {
                $sanitized['enabled'] = 0;
            }
            return $sanitized;
        }

        /**
         * Render title settings field
         */
        public function render_title_field() {
            $options = get_option( 'contact_form_plugin_options', array() );
            $title = isset( $options['title'] ) ? $options['title'] : 'Contact Form Plugin';
            echo '<input type="text" name="contact_form_plugin_options[title]" value="' . esc_attr( $title ) . '" class="regular-text" />';
        }

        /**
         * Render admin settings page
         */
        public function render_admin_settings_page() {
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_die( esc_html__( 'شما اجازه دسترسی به این بخش را ندارید.', 'contact_form_plugin' ) );
            }
            ?>
            <div class="wrap rtw-plugin-admin">
                <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
                <p><?php esc_html_e( 'از طریق شورتکد [' . 'contact_form_plugin' . '] می‌توانید کامپوننت را در هر برگه یا نوشته‌ای درج نمایید.', 'contact_form_plugin' ); ?></p>
                <form method="post" action="options.php">
                    <?php
                    settings_fields( 'contact_form_plugin_options_group' );
                    do_settings_sections( 'contact_form_plugin-settings' );
                    submit_button();
                    ?>
                </form>
            </div>
            <?php
        }

        /**
         * Render shortcode [contact_form_plugin]
         *
         * @param array $atts Shortcode attributes.
         * @return string Rendered HTML.
         */
        public function render_shortcode( $atts ) {
            $atts = shortcode_atts(
                array(
                    'title' => 'Contact Form Plugin',
                    'theme' => 'dark'
                ),
                $atts,
                'contact_form_plugin'
            );

            ob_start();
            ?>
            <div class="contact_form_plugin-widget-container bg-slate-900 text-slate-100 rounded-2xl p-6 shadow-xl border border-slate-800" data-rtw-widget="contact_form_plugin">
                <div class="widget-header flex justify-between items-center mb-6 pb-4 border-b border-slate-800">
                    <h3 class="text-xl font-bold text-white"><?php echo esc_html( $atts['title'] ); ?></h3>
                    <span class="text-xs bg-blue-600 text-white px-2 py-1 rounded-md font-semibold">
                        <?php esc_html_e( 'ویجت مستقل وردپرس', 'contact_form_plugin' ); ?>
                    </span>
                </div>

                <div class="widget-body space-y-4">
                    <p class="text-slate-300 text-sm leading-relaxed">
                        <?php esc_html_e( 'این افزونه با معماری کاملاً ماژولار و مبتنی بر استانداردهای امنیتی WPCS مستقیماً از React کامپایل شده است.', 'contact_form_plugin' ); ?>
                    </p>

                    <form class="contact_form_plugin-ajax-form space-y-3" method="post">
                        <input type="text" name="user_query" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-sm" placeholder="<?php esc_attr_e( 'درخواست یا پیام خود را بنویسید...', 'contact_form_plugin' ); ?>" required />
                        <button type="submit" class="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-2 rounded-lg text-sm transition-colors">
                            <?php esc_html_e( 'ثبت درخواست', 'contact_form_plugin' ); ?>
                        </button>
                    </form>
                </div>
            </div>
            <?php
            return ob_get_clean();
        }

        /**
         * Handle AJAX submissions securely
         */
        public function handle_ajax_submission() {
            check_ajax_referer( 'contact_form_plugin_plugin_action_nonce', 'nonce' );

            $query = isset( $_POST['user_query'] ) ? sanitize_text_field( wp_unslash( $_POST['user_query'] ) ) : '';

            if ( empty( $query ) ) {
                wp_send_json_error( array( 'message' => esc_html__( 'ورودی نمی‌تواند خالی باشد.', 'contact_form_plugin' ) ) );
            }

            wp_send_json_success( array(
                'message'   => esc_html__( 'درخواست شما با موفقیت در افزونه ثبت گردید.', 'contact_form_plugin' ),
                'processed' => esc_html( $query )
            ) );
        }
    }

    // Register Activation / Deactivation hooks
    register_activation_hook( __FILE__, array( 'Contact_Form_Plugin_Plugin_Core', 'activate' ) );
    register_deactivation_hook( __FILE__, array( 'Contact_Form_Plugin_Plugin_Core', 'deactivate' ) );

    // Initialize Plugin
    add_action( 'plugins_loaded', array( 'Contact_Form_Plugin_Plugin_Core', 'get_instance' ) );
}
